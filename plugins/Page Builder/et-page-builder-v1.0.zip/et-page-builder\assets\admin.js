/**
 * eTraining Page Builder — Admin JavaScript
 *
 * Handles all interactive behaviour in the WordPress editor:
 *  - Showing/hiding the block picker with category tab filtering
 *  - Adding new blocks (via AJAX to get server-rendered field HTML)
 *  - Toggling block field panels open/closed
 *  - Removing blocks
 *  - Adding/removing repeater items
 *  - Drag-and-drop reordering (via jQuery UI Sortable)
 *  - Collecting all field data and saving it to the hidden JSON input
 */

(function ($) {
    'use strict';

    // ── Initialise ─────────────────────────────────────────────────────────────

    $(document).ready(function () {
        bindEvents();
        initSortable('#etpb-blocks-list');
    });

    // ── Event bindings ─────────────────────────────────────────────────────────

    function bindEvents() {

        // Show block type picker
        $(document).on('click', '#etpb-add-block-btn', function () {
            // Reset category tabs to "All" each time the picker opens
            $('.etpb-cat-tab').removeClass('active');
            $('.etpb-cat-tab[data-category="all"]').addClass('active');
            $('.etpb-block-option').show();

            $('#etpb-block-picker').slideDown(200);
            $(this).prop('disabled', true).css('opacity', 0.5);
        });

        // Cancel adding a block
        $(document).on('click', '#etpb-cancel-add', function () {
            $('#etpb-block-picker').slideUp(200);
            $('#etpb-add-block-btn').prop('disabled', false).css('opacity', 1);
        });

        // Category tab switching
        $(document).on('click', '.etpb-cat-tab', function () {
            var cat = $(this).data('category');
            $('.etpb-cat-tab').removeClass('active');
            $(this).addClass('active');
            if (cat === 'all') {
                $('.etpb-block-option').show();
            } else {
                $('.etpb-block-option').each(function () {
                    $(this).toggle($(this).data('category') === cat);
                });
            }
        });

        // User chose a block type — add it
        $(document).on('click', '.etpb-block-option', function () {
            var blockType = $(this).data('type');
            addBlock(blockType);
        });

        // Toggle a block's field panel open or closed
        $(document).on('click', '.etpb-btn-toggle-fields', function () {
            var $btn    = $(this);
            var $fields = $btn.closest('.etpb-block-row').find('.etpb-block-fields');
            var isOpen  = $fields.is(':visible');

            $fields.slideToggle(200);
            $btn.text(isOpen ? '✏️ Edit' : '▲ Close');
            $btn.attr('aria-expanded', isOpen ? 'false' : 'true');
        });

        // Remove a block
        $(document).on('click', '.etpb-btn-remove', function () {
            if (!confirm('Remove this section from the page?\n\nThis will not affect any content in WordPress — it only removes the section from this page layout.')) {
                return;
            }
            $(this).closest('.etpb-block-row').remove();
            reindexBlocks();
            saveToInput();
            showEmptyStateIfNeeded();
        });

        // Add a repeater item
        $(document).on('click', '.etpb-btn-add-item', function () {
            var $repeater       = $(this).closest('.etpb-repeater');
            var $itemsContainer = $repeater.find('.etpb-repeater-items');
            var subFields       = JSON.parse($repeater.attr('data-sub-fields') || '{}');
            var currentCount    = $itemsContainer.find('.etpb-repeater-item').length;

            $itemsContainer.find('.etpb-repeater-empty').remove();

            var $newItem = buildRepeaterItemHtml(subFields, currentCount);
            $itemsContainer.append($newItem);
            saveToInput();
        });

        // Remove a repeater item
        $(document).on('click', '.etpb-btn-remove-item', function () {
            var $repeater       = $(this).closest('.etpb-repeater');
            var $itemsContainer = $repeater.find('.etpb-repeater-items');
            $(this).closest('.etpb-repeater-item').remove();

            $itemsContainer.find('.etpb-repeater-item').each(function (i) {
                $(this).find('.etpb-repeater-item-num').text('Item ' + (i + 1));
            });

            if ($itemsContainer.find('.etpb-repeater-item').length === 0) {
                $itemsContainer.append('<p class="etpb-repeater-empty">No items yet. Click the button below to add one.</p>');
            }

            saveToInput();
        });

        // Toggle label update when a checkbox changes
        $(document).on('change', '.etpb-checkbox', function () {
            var $label = $(this).closest('.etpb-toggle').find('.etpb-toggle-label');
            $label.text($(this).is(':checked') ? 'Enabled' : 'Disabled');
            saveToInput();
        });

        // Save whenever any field value changes
        $(document).on('change keyup', '.etpb-field-value, .etpb-sub-field-value', function () {
            saveToInput();
        });
    }

    // ── Add a new block ─────────────────────────────────────────────────────────

    function addBlock(blockType) {
        $('#etpb-block-picker').slideUp(200);
        $('#etpb-add-block-btn').prop('disabled', false).css('opacity', 1);

        $('#etpb-empty-state').remove();

        var nextIndex = $('#etpb-blocks-list .etpb-block-row').length;

        var $placeholder = $('<div class="etpb-block-row etpb-loading-row" style="padding:16px;color:#757575;">' +
            '⏳ Adding section…</div>');
        $('#etpb-blocks-list').append($placeholder);

        $.post(etpbData.ajaxUrl, {
            action:      'etpb_get_block_fields',
            nonce:       etpbData.nonce,
            block_type:  blockType,
            block_index: nextIndex,
        }, function (response) {
            $placeholder.remove();

            if (response.success && response.data.html) {
                var $newRow = $(response.data.html);
                $('#etpb-blocks-list').append($newRow);

                $newRow.find('.etpb-block-fields').show();
                $newRow.find('.etpb-btn-toggle-fields').text('▲ Close').attr('aria-expanded', 'true');

                $('html, body').animate({
                    scrollTop: $newRow.offset().top - 80
                }, 300);

                initSortable('#etpb-blocks-list');
                saveToInput();
            } else {
                alert('Something went wrong adding that section. Please try again.');
            }
        }).fail(function () {
            $placeholder.remove();
            alert('Could not connect to WordPress. Please refresh and try again.');
        });
    }

    // ── Drag-and-drop reordering ────────────────────────────────────────────────

    function initSortable(selector) {
        $(selector).sortable({
            handle:      '.etpb-drag-handle',
            placeholder: 'etpb-block-row-placeholder',
            tolerance:   'pointer',
            update: function () {
                reindexBlocks();
                saveToInput();
            }
        });
    }

    function reindexBlocks() {
        $('#etpb-blocks-list .etpb-block-row').each(function (newIndex) {
            $(this).attr('data-index', newIndex);
        });
    }

    // ── Collect data from DOM and save to hidden input ─────────────────────────

    function saveToInput() {
        var blocks = [];

        $('#etpb-blocks-list .etpb-block-row').each(function () {
            var blockType = $(this).data('type');
            var fields    = {};

            // Collect simple (non-repeater) fields
            $(this).find('.etpb-field').each(function () {
                var fieldKey = $(this).data('field-key');
                var $value   = $(this).find('> .etpb-field-value, > label.etpb-toggle .etpb-field-value');

                if ($value.length === 0) {
                    return; // Repeater — handled below
                }

                if ($value.attr('type') === 'checkbox') {
                    fields[fieldKey] = $value.is(':checked');
                } else {
                    fields[fieldKey] = $value.val() || '';
                }
            });

            // Collect repeater fields
            $(this).find('.etpb-repeater').each(function () {
                var fieldKey = $(this).data('field-key');
                var items    = [];

                $(this).find('.etpb-repeater-item').each(function () {
                    var item = {};
                    $(this).find('.etpb-sub-field').each(function () {
                        var subKey = $(this).data('sub-key');
                        item[subKey] = $(this).find('.etpb-sub-field-value').val() || '';
                    });
                    items.push(item);
                });

                fields[fieldKey] = items;
            });

            blocks.push({
                type:   blockType,
                fields: fields,
            });
        });

        $('#etpb-blocks-config').val(JSON.stringify(blocks));
    }

    // ── Utility functions ───────────────────────────────────────────────────────

    function showEmptyStateIfNeeded() {
        if ($('#etpb-blocks-list .etpb-block-row').length === 0) {
            $('#etpb-blocks-list').html(
                '<div class="etpb-empty-state" id="etpb-empty-state">' +
                '<div class="etpb-empty-icon">📄</div>' +
                '<p><strong>No sections added yet.</strong></p>' +
                '<p>Click <strong>"＋ Add a Section"</strong> below to start building this page.</p>' +
                '</div>'
            );
        }
    }

    /**
     * Build the HTML for a new empty repeater item.
     */
    function buildRepeaterItemHtml(subFields, index) {
        var $item = $('<div class="etpb-repeater-item"></div>');

        $item.append(
            '<div class="etpb-repeater-item-header">' +
            '<span class="etpb-drag-handle" title="Drag to reorder">⠿</span>' +
            '<span class="etpb-repeater-item-num">Item ' + (index + 1) + '</span>' +
            '<button type="button" class="etpb-btn-remove-item">✕ Remove</button>' +
            '</div>'
        );

        $.each(subFields, function (subKey, subField) {
            var $subField = $('<div class="etpb-sub-field" data-sub-key="' + subKey + '"></div>');
            $subField.append('<label>' + subField.label + '</label>');

            if (subField.type === 'icon_picker') {
                $subField.append(
                    '<input type="text" class="etpb-input etpb-sub-field-value" ' +
                    'placeholder="e.g. fas fa-check-circle" value="" />' +
                    '<small style="color:#757575;font-size:11px;">Type a Font Awesome icon class, or leave blank for no icon.</small>'
                );
            } else if (subField.type === 'textarea') {
                $subField.append(
                    '<textarea class="etpb-textarea etpb-sub-field-value" rows="3"></textarea>'
                );
            } else {
                $subField.append(
                    '<input type="text" class="etpb-input etpb-sub-field-value" value="" />'
                );
            }

            $item.append($subField);
        });

        return $item;
    }

})(jQuery);
