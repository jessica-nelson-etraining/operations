<?php
/**
 * admin-interface.php — eTraining Page Builder
 *
 * Everything related to the WordPress admin editor panel.
 * This file:
 *  - Adds the "eTraining Page Builder" meta box to the page editor
 *  - Renders the block list, category tabs, "Add a Section" picker, and all field inputs
 *  - Saves the block configuration when the page is saved
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Register the meta box that appears on all page edit screens.
 */
function etpb_add_meta_box() {
    add_meta_box(
        'etpb_block_editor',
        '🧱 eTraining Page Builder',
        'etpb_render_meta_box',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'etpb_add_meta_box' );

/**
 * Render the entire meta box content.
 */
function etpb_render_meta_box( $post ) {
    $blocks      = etpb_get_page_blocks( $post->ID );
    $definitions = etpb_get_block_definitions();

    // Security nonce
    wp_nonce_field( 'etpb_save_blocks', 'etpb_nonce' );

    // Get saved product connection values
    $saved_product_id   = get_post_meta( $post->ID, 'Product ID',   true );
    $saved_product_slug = get_post_meta( $post->ID, 'Product SLUG', true );
    ?>

    <div id="etpb-editor" class="etpb-editor">

        <div class="etpb-intro">
            <strong>eTraining Page Builder</strong><br>
            Use the sections below to build this page.
            Add sections using the button below, drag the <strong>⠿</strong> handle to reorder them,
            and click <strong>✏️ Edit</strong> to configure each one.
            Click <strong>Update</strong> in the top right to save your changes.
        </div>

        <!-- ── WooCommerce Product Connection ── -->
        <div class="etpb-product-connection">
            <div class="etpb-product-connection-title">
                🔗 WooCommerce Product Connection
            </div>
            <p class="etpb-field-desc">
                Connect this page to a WooCommerce product so the price and enroll button
                link update automatically. Both fields are required for dynamic pricing to work.
            </p>
            <div class="etpb-product-fields">
                <div class="etpb-product-field">
                    <label class="etpb-field-label" for="etpb_product_id_input">
                        Product ID
                    </label>
                    <p class="etpb-field-desc">
                        The WooCommerce product number. Find it by editing the product in
                        WooCommerce — it appears in the browser URL as <code>post=123</code>.
                    </p>
                    <input type="text"
                           id="etpb_product_id_input"
                           name="etpb_product_id"
                           class="etpb-input"
                           value="<?php echo esc_attr( $saved_product_id ); ?>"
                           placeholder="e.g. 123" />
                </div>
                <div class="etpb-product-field">
                    <label class="etpb-field-label" for="etpb_product_slug_input">
                        Product SLUG
                    </label>
                    <p class="etpb-field-desc">
                        The URL-friendly product name. Find it in WooCommerce under
                        Product data → Advanced → Slug. Example: <code>hazwoper-9-hour-refresher</code>
                    </p>
                    <input type="text"
                           id="etpb_product_slug_input"
                           name="etpb_product_slug"
                           class="etpb-input"
                           value="<?php echo esc_attr( $saved_product_slug ); ?>"
                           placeholder="e.g. hazwoper-9-hour-refresher" />
                </div>
            </div>
            <?php if ( $saved_product_id && function_exists( 'wc_get_product' ) ) :
                $preview_product = wc_get_product( (int) $saved_product_id );
                if ( $preview_product ) : ?>
                    <div class="etpb-product-connected">
                        ✅ Connected to: <strong><?php echo esc_html( $preview_product->get_name() ); ?></strong>
                        — Price: <strong><?php echo wc_price( $preview_product->get_price() ); ?></strong>
                    </div>
                <?php else : ?>
                    <div class="etpb-product-not-found">
                        ⚠️ No product found with ID <strong><?php echo esc_html( $saved_product_id ); ?></strong>.
                        Double-check the ID in WooCommerce.
                    </div>
                <?php endif;
            endif; ?>
        </div>

        <!-- ── Course Outline ── -->
        <?php $saved_outline = get_post_meta( $post->ID, 'Course Outline', true ); ?>
        <div class="etpb-course-outline-wrap">
            <div class="etpb-product-connection-title">
                📋 Course Outline
            </div>
            <p class="etpb-field-desc">
                This content appears in the popup when a visitor clicks the
                <strong>Course Outline Button</strong> block. Use the editor below to add
                bullet points, numbered lists, headings, or any formatted content.
                Leave blank to hide the Course Outline Button automatically.
            </p>
            <?php
            wp_editor(
                $saved_outline,
                'etpb_course_outline',
                array(
                    'textarea_name' => 'etpb_course_outline',
                    'textarea_rows' => 10,
                    'media_buttons' => false,
                    'teeny'         => false,
                    'tinymce'       => array(
                        'toolbar1' => 'bold,italic,bullist,numlist,blockquote,hr,link,unlink,undo,redo',
                        'toolbar2' => '',
                    ),
                    'quicktags'     => array(
                        'buttons' => 'strong,em,ul,ol,li,close',
                    ),
                )
            );
            ?>
        </div>

        <!-- ── Active blocks list ── -->
        <div class="etpb-blocks-list" id="etpb-blocks-list">
            <?php if ( empty( $blocks ) ) : ?>
                <div class="etpb-empty-state" id="etpb-empty-state">
                    <div class="etpb-empty-icon">📄</div>
                    <p><strong>No sections added yet.</strong></p>
                    <p>Click <strong>"＋ Add a Section"</strong> below to start building this page.</p>
                </div>
            <?php else : ?>
                <?php foreach ( $blocks as $index => $block ) : ?>
                    <?php etpb_render_block_editor_row( $index, $block, $definitions ); ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- ── Add Section button ── -->
        <div class="etpb-add-block-wrap">
            <button type="button" class="etpb-btn etpb-btn-add" id="etpb-add-block-btn">
                ＋ Add a Section
            </button>
        </div>

        <!-- ── Block type picker (hidden until "Add a Section" is clicked) ── -->
        <div class="etpb-block-picker" id="etpb-block-picker" style="display:none;">
            <h3>Choose a Section Type</h3>
            <p class="etpb-picker-sub">Filter by category, then click a section type to add it.</p>

            <!-- Category filter tabs -->
            <div class="etpb-category-tabs">
                <button type="button" class="etpb-cat-tab active" data-category="all">All</button>
                <button type="button" class="etpb-cat-tab" data-category="Course">Course</button>
                <button type="button" class="etpb-cat-tab" data-category="General">General</button>
                <button type="button" class="etpb-cat-tab" data-category="Social Proof">Social Proof</button>
            </div>

            <div class="etpb-block-picker-grid">
                <?php foreach ( $definitions as $type => $def ) : ?>
                    <div class="etpb-block-option"
                         data-type="<?php echo esc_attr( $type ); ?>"
                         data-category="<?php echo esc_attr( $def['category'] ); ?>">
                        <div class="etpb-block-option-icon"><?php echo $def['icon']; ?></div>
                        <div class="etpb-block-option-label"><?php echo esc_html( $def['label'] ); ?></div>
                        <div class="etpb-block-option-desc"><?php echo esc_html( $def['description'] ); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="etpb-btn etpb-btn-cancel" id="etpb-cancel-add">
                ✕ Cancel
            </button>
        </div>

        <!-- ── Hidden field: stores all block data as JSON ── -->
        <input type="hidden"
               name="etpb_blocks_config"
               id="etpb-blocks-config"
               value="<?php echo esc_attr( json_encode( $blocks ) ); ?>" />

    </div><!-- /#etpb-editor -->
    <?php
}

/**
 * Render a single block row in the editor.
 */
function etpb_render_block_editor_row( $index, $block, $definitions ) {
    $type = $block['type'] ?? '';
    $def  = $definitions[ $type ] ?? null;
    if ( ! $def ) return;
    ?>
    <div class="etpb-block-row" data-index="<?php echo (int) $index; ?>" data-type="<?php echo esc_attr( $type ); ?>">

        <div class="etpb-block-header">
            <span class="etpb-drag-handle" title="Drag to reorder this section">⠿</span>
            <span class="etpb-block-icon"><?php echo $def['icon']; ?></span>
            <span class="etpb-block-title"><?php echo esc_html( $def['label'] ); ?></span>
            <div class="etpb-block-actions">
                <button type="button" class="etpb-btn-toggle-fields" aria-expanded="false">
                    ✏️ Edit
                </button>
                <button type="button" class="etpb-btn-remove" title="Remove this section">
                    🗑️ Remove
                </button>
            </div>
        </div>

        <div class="etpb-block-fields" style="display:none;" aria-hidden="true">
            <p class="etpb-fields-desc"><?php echo esc_html( $def['description'] ); ?></p>
            <?php foreach ( $def['fields'] as $field_key => $field ) : ?>
                <?php
                $saved_value = $block['fields'][ $field_key ] ?? null;
                etpb_render_field( $index, $field_key, $field, $saved_value );
                ?>
            <?php endforeach; ?>
        </div>

    </div>
    <?php
}

/**
 * Render a single field inside a block's edit area.
 */
function etpb_render_field( $block_index, $field_key, $field, $value ) {
    $field_id = 'etpb_block_' . $block_index . '_' . $field_key;
    $type     = $field['type'] ?? 'text';
    ?>
    <div class="etpb-field" data-field-key="<?php echo esc_attr( $field_key ); ?>">

        <label class="etpb-field-label" for="<?php echo esc_attr( $field_id ); ?>">
            <?php echo esc_html( $field['label'] ); ?>
        </label>

        <?php if ( ! empty( $field['description'] ) ) : ?>
            <p class="etpb-field-desc"><?php echo esc_html( $field['description'] ); ?></p>
        <?php endif; ?>

        <?php
        $display_value = $value ?? $field['default'] ?? '';

        switch ( $type ) :

            case 'text': ?>
                <input type="text"
                       id="<?php echo esc_attr( $field_id ); ?>"
                       class="etpb-input etpb-field-value"
                       value="<?php echo esc_attr( $display_value ); ?>" />
                <?php break;

            case 'textarea': ?>
                <textarea id="<?php echo esc_attr( $field_id ); ?>"
                          class="etpb-textarea etpb-field-value"
                          rows="3"><?php echo esc_textarea( $display_value ); ?></textarea>
                <?php break;

            case 'select': ?>
                <select id="<?php echo esc_attr( $field_id ); ?>"
                        class="etpb-select etpb-field-value">
                    <?php foreach ( $field['options'] as $opt_val => $opt_label ) : ?>
                        <option value="<?php echo esc_attr( $opt_val ); ?>"
                            <?php selected( $display_value, $opt_val ); ?>>
                            <?php echo esc_html( $opt_label ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php break;

            case 'toggle':
                $is_checked = isset( $value ) ? (bool) $value : (bool) ( $field['default'] ?? false );
                ?>
                <label class="etpb-toggle">
                    <input type="checkbox"
                           class="etpb-checkbox etpb-field-value"
                           <?php checked( $is_checked ); ?> />
                    <span class="etpb-toggle-slider"></span>
                    <span class="etpb-toggle-label">
                        <?php echo $is_checked ? 'Enabled' : 'Disabled'; ?>
                    </span>
                </label>
                <?php break;

            case 'icon_picker': ?>
                <select id="<?php echo esc_attr( $field_id ); ?>"
                        class="etpb-select etpb-field-value">
                    <?php foreach ( etpb_get_available_icons() as $icon_val => $icon_label ) : ?>
                        <option value="<?php echo esc_attr( $icon_val ); ?>"
                            <?php selected( $display_value, $icon_val ); ?>>
                            <?php echo esc_html( $icon_label ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php break;

            case 'repeater':
                $items = is_array( $value ) ? $value : array();
                ?>
                <div class="etpb-repeater"
                     data-field-key="<?php echo esc_attr( $field_key ); ?>"
                     data-sub-fields="<?php echo esc_attr( json_encode( $field['sub_fields'] ) ); ?>">

                    <div class="etpb-repeater-items">
                        <?php foreach ( $items as $item_index => $item_data ) : ?>
                            <?php etpb_render_repeater_item( $field['sub_fields'], $item_index, $item_data ); ?>
                        <?php endforeach; ?>
                        <?php if ( empty( $items ) ) : ?>
                            <p class="etpb-repeater-empty">No items yet. Click the button below to add one.</p>
                        <?php endif; ?>
                    </div>

                    <button type="button" class="etpb-btn-add-item">
                        ＋ Add Item
                    </button>
                </div>
                <?php break;

        endswitch;
        ?>
    </div>
    <?php
}

/**
 * Render a single item inside a repeater field.
 */
function etpb_render_repeater_item( $sub_fields, $index, $values = array() ) {
    ?>
    <div class="etpb-repeater-item">
        <div class="etpb-repeater-item-header">
            <span class="etpb-drag-handle" title="Drag to reorder">⠿</span>
            <span class="etpb-repeater-item-num">Item <?php echo (int) $index + 1; ?></span>
            <button type="button" class="etpb-btn-remove-item">✕ Remove</button>
        </div>
        <?php foreach ( $sub_fields as $sub_key => $sub_field ) : ?>
            <div class="etpb-sub-field" data-sub-key="<?php echo esc_attr( $sub_key ); ?>">
                <label><?php echo esc_html( $sub_field['label'] ); ?></label>
                <?php if ( $sub_field['type'] === 'icon_picker' ) : ?>
                    <select class="etpb-select etpb-sub-field-value">
                        <?php foreach ( etpb_get_available_icons() as $icon_val => $icon_label ) : ?>
                            <option value="<?php echo esc_attr( $icon_val ); ?>"
                                <?php selected( $values[ $sub_key ] ?? '', $icon_val ); ?>>
                                <?php echo esc_html( $icon_label ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php elseif ( isset( $sub_field['type'] ) && $sub_field['type'] === 'textarea' ) : ?>
                    <textarea class="etpb-textarea etpb-sub-field-value"
                              rows="3"><?php echo esc_textarea( $values[ $sub_key ] ?? '' ); ?></textarea>
                <?php else : ?>
                    <input type="text"
                           class="etpb-input etpb-sub-field-value"
                           value="<?php echo esc_attr( $values[ $sub_key ] ?? '' ); ?>" />
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
}

/**
 * Save block configuration when a page is saved.
 */
function etpb_save_blocks( $post_id ) {
    if ( ! isset( $_POST['etpb_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['etpb_nonce'], 'etpb_save_blocks' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    if ( 'page' !== get_post_type( $post_id ) ) return;

    if ( isset( $_POST['etpb_blocks_config'] ) ) {
        $raw     = wp_unslash( $_POST['etpb_blocks_config'] );
        $decoded = json_decode( $raw, true );

        if ( is_array( $decoded ) ) {
            update_post_meta( $post_id, 'etpb_blocks_config', wp_slash( $raw ) );
        }
    }

    // Save Product ID
    if ( isset( $_POST['etpb_product_id'] ) ) {
        $product_id = sanitize_text_field( wp_unslash( $_POST['etpb_product_id'] ) );
        update_post_meta( $post_id, 'Product ID', $product_id );
    }

    // Save Product SLUG
    if ( isset( $_POST['etpb_product_slug'] ) ) {
        $product_slug = sanitize_title( wp_unslash( $_POST['etpb_product_slug'] ) );
        update_post_meta( $post_id, 'Product SLUG', $product_slug );
    }

    // Save Course Outline
    if ( isset( $_POST['etpb_course_outline'] ) ) {
        $outline = wp_kses_post( wp_unslash( $_POST['etpb_course_outline'] ) );
        update_post_meta( $post_id, 'Course Outline', $outline );
    }
}
add_action( 'save_post', 'etpb_save_blocks' );
