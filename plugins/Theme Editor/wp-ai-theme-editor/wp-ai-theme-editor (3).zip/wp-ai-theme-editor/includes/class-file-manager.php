<?php
/**
 * WPAI_File_Manager — File discovery, path validation, and file I/O.
 *
 * FILE KEY FORMAT:
 *   theme:{relative}        e.g. "theme:functions.php", "theme:includes/nav.php"
 *   child:{relative}        e.g. "child:style.css"
 *   plugin:{folder}:{rel}   e.g. "plugin:core-blocks:core-blocks.php"
 *
 * This format encodes the root and relative path so resolve_path() can
 * validate access without any ambiguity. The key is safe to send to the
 * browser (no absolute server paths exposed).
 *
 * SECURITY:
 *   resolve_path() uses realpath() to resolve symlinks and then verifies the
 *   result starts with the allowed root. This blocks all path traversal
 *   attempts including "../", "%2e%2e/", symlink escapes, etc.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WPAI_File_Manager {

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Returns a flat list of all files the editor is allowed to access,
     * grouped by source (Theme, Child Theme, Plugin name).
     *
     * @return array[] Each entry: { key, label, type, group }
     */
    public function get_file_list(): array {
        $files = array();

        // Active theme
        $theme_dir  = get_template_directory();
        $theme_name = wp_get_theme()->get( 'Name' );
        $files = array_merge(
            $files,
            $this->scan_directory( $theme_dir, array( 'php', 'css' ), 'Theme: ' . $theme_name, 'theme', $theme_dir )
        );

        // Child theme (if different from parent)
        $child_dir = get_stylesheet_directory();
        if ( realpath( $child_dir ) !== realpath( $theme_dir ) ) {
            $child_name = wp_get_theme()->get( 'Name' ) . ' (Child)';
            $files = array_merge(
                $files,
                $this->scan_directory( $child_dir, array( 'php', 'css' ), 'Child: ' . $child_name, 'child', $child_dir )
            );
        }

        // Allowed plugin folders
        foreach ( WPAI_Settings::get_allowed_plugins() as $folder ) {
            $plugin_dir = WP_PLUGIN_DIR . '/' . sanitize_file_name( $folder );
            if ( is_dir( $plugin_dir ) ) {
                $files = array_merge(
                    $files,
                    $this->scan_directory(
                        $plugin_dir,
                        array( 'php', 'css' ),
                        'Plugin: ' . $folder,
                        'plugin:' . $folder,
                        $plugin_dir
                    )
                );
            }
        }

        return $files;
    }

    /**
     * Resolves a file key to an absolute server path.
     * Returns WP_Error if the key is invalid, the file doesn't exist,
     * the path escapes its allowed root, or the extension isn't PHP/CSS.
     *
     * @param string $file_key
     * @return string|WP_Error Absolute path on success.
     */
    public function resolve_path( string $file_key ) {
        // Parse key prefix to determine root
        if ( strpos( $file_key, 'theme:' ) === 0 ) {
            $root     = get_template_directory();
            $relative = substr( $file_key, 6 );

        } elseif ( strpos( $file_key, 'child:' ) === 0 ) {
            $root     = get_stylesheet_directory();
            $relative = substr( $file_key, 6 );

        } elseif ( strpos( $file_key, 'plugin:' ) === 0 ) {
            $rest  = substr( $file_key, 7 );
            $colon = strpos( $rest, ':' );
            if ( $colon === false ) {
                return new WP_Error( 'invalid_key', 'Invalid plugin key format.', array( 'status' => 400 ) );
            }
            $folder   = sanitize_file_name( substr( $rest, 0, $colon ) );
            $relative = substr( $rest, $colon + 1 );

            // Must be in the admin-approved list
            if ( ! in_array( $folder, WPAI_Settings::get_allowed_plugins(), true ) ) {
                return new WP_Error( 'access_denied', 'Plugin folder not in allowed list.', array( 'status' => 403 ) );
            }
            $root = WP_PLUGIN_DIR . '/' . $folder;

        } else {
            return new WP_Error( 'invalid_key', 'Unrecognised file key format.', array( 'status' => 400 ) );
        }

        // Strip any traversal sequences from the relative segment
        $relative = ltrim( $relative, '/\\' );
        $relative = str_replace( array( '../', '..\\', '..' ), '', $relative );

        $full_path = $root . DIRECTORY_SEPARATOR . str_replace( '/', DIRECTORY_SEPARATOR, $relative );
        $candidate = realpath( $full_path );

        if ( $candidate === false ) {
            return new WP_Error( 'not_found', 'File not found.', array( 'status' => 404 ) );
        }

        // Security: candidate must be inside the resolved root
        $resolved_root = realpath( $root );
        if ( $resolved_root === false || strpos( $candidate, $resolved_root . DIRECTORY_SEPARATOR ) !== 0
             && $candidate !== $resolved_root ) {
            return new WP_Error( 'access_denied', 'Path traversal attempt detected.', array( 'status' => 403 ) );
        }

        // Only PHP and CSS files
        $ext = strtolower( pathinfo( $candidate, PATHINFO_EXTENSION ) );
        if ( ! in_array( $ext, array( 'php', 'css' ), true ) ) {
            return new WP_Error( 'invalid_type', 'Only PHP and CSS files can be edited.', array( 'status' => 400 ) );
        }

        return $candidate;
    }

    /**
     * Reads a file's content.
     *
     * @param string $file_key
     * @return string|WP_Error File content on success.
     */
    public function read_file( string $file_key ) {
        $path = $this->resolve_path( $file_key );
        if ( is_wp_error( $path ) ) return $path;

        $this->init_filesystem();
        global $wp_filesystem;

        if ( $wp_filesystem ) {
            $content = $wp_filesystem->get_contents( $path );
        } else {
            $content = @file_get_contents( $path );
        }

        if ( $content === false ) {
            return new WP_Error( 'read_error', 'Could not read file.', array( 'status' => 500 ) );
        }

        return $content;
    }

    /**
     * Writes content to a file.
     * Does NOT back up — the caller (REST handler) must create a backup first.
     *
     * @param string $file_key
     * @param string $content
     * @return true|WP_Error
     */
    public function write_file( string $file_key, string $content ) {
        $path = $this->resolve_path( $file_key );
        if ( is_wp_error( $path ) ) return $path;

        $this->init_filesystem();
        global $wp_filesystem;

        if ( $wp_filesystem ) {
            $result = $wp_filesystem->put_contents( $path, $content, FS_CHMOD_FILE );
        } else {
            $result = @file_put_contents( $path, $content );
        }

        if ( $result === false || $result === null ) {
            return new WP_Error( 'write_error', 'Could not write file. Check file permissions.', array( 'status' => 500 ) );
        }

        return true;
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * Recursively scans a directory for PHP and CSS files.
     *
     * @param string   $dir        Current directory to scan.
     * @param string[] $extensions e.g. ['php', 'css']
     * @param string   $group      Label for the dropdown optgroup.
     * @param string   $key_prefix e.g. 'theme', 'child', 'plugin:core-blocks'
     * @param string   $root       Absolute path of the scan root (for key generation).
     * @param int      $depth      Current recursion depth (max 4).
     * @return array[]
     */
    private function scan_directory(
        string $dir,
        array $extensions,
        string $group,
        string $key_prefix,
        string $root,
        int $depth = 0
    ): array {
        $files = array();
        if ( $depth > 4 ) return $files;
        if ( ! is_dir( $dir ) || ! is_readable( $dir ) ) return $files;

        $skip = array( 'node_modules', '.git', 'vendor', '.svn', 'ai-editor-backups', 'ai-editor-previews', '.cache' );

        $items = @scandir( $dir );
        if ( ! $items ) return $files;

        foreach ( $items as $item ) {
            if ( $item === '.' || $item === '..' ) continue;
            if ( in_array( $item, $skip, true ) ) continue;

            $full_path = $dir . DIRECTORY_SEPARATOR . $item;

            if ( is_dir( $full_path ) ) {
                $sub = $this->scan_directory( $full_path, $extensions, $group, $key_prefix, $root, $depth + 1 );
                $files = array_merge( $files, $sub );
            } elseif ( is_file( $full_path ) ) {
                $ext = strtolower( pathinfo( $item, PATHINFO_EXTENSION ) );
                if ( in_array( $ext, $extensions, true ) ) {
                    // Build relative path from root, always using forward slashes
                    $relative = ltrim( str_replace( '\\', '/', str_replace( realpath( $root ), '', realpath( $full_path ) ) ), '/' );
                    $key      = $key_prefix . ':' . $relative;

                    $files[] = array(
                        'key'   => $key,
                        'label' => $relative,
                        'type'  => $ext,
                        'group' => $group,
                    );
                }
            }
        }

        // Sort files alphabetically within each directory level
        usort( $files, function( $a, $b ) {
            return strcmp( $a['label'], $b['label'] );
        } );

        return $files;
    }

    private function init_filesystem(): void {
        global $wp_filesystem;
        if ( $wp_filesystem ) return;
        if ( ! function_exists( 'WP_Filesystem' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        WP_Filesystem();
    }
}
