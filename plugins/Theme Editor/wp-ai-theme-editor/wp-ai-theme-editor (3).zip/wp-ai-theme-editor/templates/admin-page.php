<?php
/**
 * Admin page template — WP AI Theme Editor
 * Variables available: $api_key_missing (bool)
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="wrap" id="wpai-editor">

    <?php if ( $api_key_missing ) : ?>
        <div class="notice notice-warning" style="margin:16px 0 0;">
            <p>
                <strong>API key not set.</strong>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpai-settings' ) ); ?>">Go to Settings</a>
                to add your Anthropic API key before using the editor.
            </p>
        </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="wpai-header">
        <h1 class="wpai-title">AI Theme Editor</h1>
        <div class="wpai-header-links">
            <button id="wpai-help-toggle" class="wpai-settings-link" type="button">? How to use</button>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpai-settings' ) ); ?>" class="wpai-settings-link">
                ⚙ Settings
            </a>
        </div>
    </div>

    <!-- How to use (collapsible) -->
    <div id="wpai-help-section" class="wpai-help-section" style="display:none;">
        <div class="wpai-help-grid">
            <div class="wpai-help-item">
                <div class="wpai-help-icon">1</div>
                <div>
                    <strong>Load a file</strong><br>
                    Select any theme or plugin file from the dropdown and click <em>Load File</em>. The code appears in the viewer on the left.
                </div>
            </div>
            <div class="wpai-help-item">
                <div class="wpai-help-icon">2</div>
                <div>
                    <strong>Edit directly</strong><br>
                    Click anywhere in the code viewer and type. When you're done, click <em>Save File</em> — a backup is created automatically before saving.
                </div>
            </div>
            <div class="wpai-help-item">
                <div class="wpai-help-icon">3</div>
                <div>
                    <strong>Ask the AI a question</strong><br>
                    Use <em>Question mode</em> to ask what any part of the file does (e.g. "where is the header font set?"). The AI will explain it and highlight the relevant lines.
                </div>
            </div>
            <div class="wpai-help-item">
                <div class="wpai-help-icon">4</div>
                <div>
                    <strong>Ask the AI to make a change</strong><br>
                    Switch to <em>Edit mode</em> and describe what you want (e.g. "change the button color to dark blue"). The AI shows a before/after diff — review it, then click <em>Apply</em>.
                </div>
            </div>
            <div class="wpai-help-item">
                <div class="wpai-help-icon">5</div>
                <div>
                    <strong>Preview before applying</strong><br>
                    After the AI proposes changes, click <em>Preview in New Tab</em> to see how the site looks before committing anything.
                </div>
            </div>
            <div class="wpai-help-item">
                <div class="wpai-help-icon">6</div>
                <div>
                    <strong>Restore a backup</strong><br>
                    Every save creates a timestamped backup. Click <em>Backups ▾</em> in the panel header to list them and restore any previous version.
                </div>
            </div>
        </div>
    </div>

    <!-- File Browser -->
    <div class="wpai-file-browser">
        <div class="wpai-file-browser-row">
            <select id="wpai-file-select" class="wpai-select">
                <option value="">— Loading files… —</option>
            </select>
            <button id="wpai-load-file" class="wpai-btn wpai-btn-primary" disabled>
                Load File
            </button>
        </div>
        <div id="wpai-file-info" class="wpai-file-info" style="display:none;"></div>
    </div>

    <!-- Main Workspace (hidden until a file is loaded) -->
    <div id="wpai-workspace" style="display:none;">

        <div class="wpai-columns">

            <!-- LEFT: Code Viewer -->
            <div class="wpai-col-code">
                <div class="wpai-panel">
                    <div class="wpai-panel-header">
                        <span id="wpai-current-filename" class="wpai-filename">—</span>
                        <span id="wpai-dirty-indicator" class="wpai-dirty-indicator" style="display:none;">● Unsaved</span>
                        <div class="wpai-panel-actions">
                            <button id="wpai-save-btn" class="wpai-btn wpai-btn-success wpai-btn-small" style="display:none;" title="Save your edits to the live file (backup created automatically)">
                                💾 Save File
                            </button>
                            <button id="wpai-copy-btn" class="wpai-btn wpai-btn-small" title="Copy file contents to clipboard">
                                📋 Copy
                            </button>
                            <div class="wpai-backup-wrap">
                                <button id="wpai-backups-btn" class="wpai-btn wpai-btn-small">
                                    💾 Backups ▾
                                </button>
                                <div id="wpai-backups-dropdown" class="wpai-dropdown" style="display:none;">
                                    <div class="wpai-dropdown-inner">
                                        <p class="wpai-dropdown-loading">Loading backups…</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="wpai-editor-wrap" class="wpai-editor-wrap">
                        <textarea id="wpai-code-editor"></textarea>
                    </div>
                </div>
            </div>

            <!-- RIGHT: AI Chat Panel -->
            <div class="wpai-col-chat">
                <div class="wpai-panel wpai-chat-panel">
                    <div class="wpai-panel-header">
                        <span>AI Assistant</span>
                        <div class="wpai-mode-toggle">
                            <label class="wpai-mode-label wpai-mode-active" id="wpai-mode-question-label">
                                <input type="radio" name="wpai_mode" value="question" checked>
                                Question
                            </label>
                            <label class="wpai-mode-label" id="wpai-mode-edit-label">
                                <input type="radio" name="wpai_mode" value="edit">
                                Edit
                            </label>
                        </div>
                    </div>

                    <div id="wpai-chat-messages" class="wpai-chat-messages">
                        <div class="wpai-chat-intro" id="wpai-chat-intro">
                            <p>
                                <strong>Question mode:</strong> Ask what any part of this file does — the AI will explain it in plain English and highlight the relevant lines.
                            </p>
                            <p>
                                <strong>Edit mode:</strong> Describe a change you want to make — the AI will show you exactly what will change before saving anything.
                            </p>
                            <p class="wpai-chat-tip">
                                Tip: Press <kbd>Ctrl+Enter</kbd> (or <kbd>⌘+Enter</kbd> on Mac) to send.
                            </p>
                        </div>
                    </div>

                    <div class="wpai-chat-input-wrap">
                        <textarea
                            id="wpai-chat-input"
                            class="wpai-chat-input"
                            placeholder="Ask a question about this file…"
                            rows="3"
                            disabled
                        ></textarea>
                        <div class="wpai-chat-controls">
                            <button id="wpai-send-btn" class="wpai-btn wpai-btn-primary" disabled>
                                Send
                            </button>
                            <button id="wpai-cancel-btn" class="wpai-btn wpai-btn-secondary" style="display:none;">
                                ✕ Cancel
                            </button>
                        </div>
                    </div>

                </div><!-- .wpai-chat-panel -->
            </div><!-- .wpai-col-chat -->

        </div><!-- .wpai-columns -->

        <!-- Diff Panel (hidden until an edit response arrives) -->
        <div id="wpai-diff-panel" class="wpai-panel wpai-diff-panel" style="display:none;">
            <div class="wpai-panel-header">
                <span>Proposed Changes</span>
                <span id="wpai-diff-summary" class="wpai-diff-summary-text"></span>
            </div>
            <div id="wpai-diff-container" class="wpai-diff-container"></div>
            <div class="wpai-diff-actions">
                <button id="wpai-apply-btn" class="wpai-btn wpai-btn-success">
                    ✓ Apply Changes
                </button>
                <button id="wpai-preview-btn" class="wpai-btn wpai-btn-secondary">
                    👁 Preview in New Tab
                </button>
                <button id="wpai-discard-btn" class="wpai-btn wpai-btn-danger">
                    ✕ Discard
                </button>
            </div>
        </div>

    </div><!-- #wpai-workspace -->

    <!-- Notices injected here by JS -->
    <div id="wpai-notices" class="wpai-notices"></div>

    <!-- Loading overlay (injected by JS when needed) -->

</div><!-- #wpai-editor -->
